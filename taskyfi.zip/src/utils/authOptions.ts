// NextAuth entication settings

import { MongoDBAdapter } from "@next-auth/mongodb-adapter"
import CredentialsProvider from "next-auth/providers/credentials"
import clientPromise from "@/app/utils/db"
import type { AuthOptions } from "next-auth"

export const authOptions: AuthOptions = {
	adapter: MongoDBAdapter( clientPromise ),
	providers: [
		CredentialsProvider({
			name: "Credentials",
			credentials: {
				email: { label: "Email", type: "email" },
				password: { label: "Password", type: "password" }
			},

			async authorize( credentials ) {
				// Mock user verification logic (replace with actual DB lookup)
				if (
						credentials?.email === "test@example.com" &&
						credentials?.password === "password"
					) {
					return { id: "1", name: "Test User", email: credentials.email }
				}
				return null
			}
		})
	],

	session: {
		strategy: "jwt",
	},

	secret: process.env.NEXTAUTH_SECRET
}