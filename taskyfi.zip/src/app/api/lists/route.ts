import { NextResponse } from "next/server"
import { connectToDB } from "@/app/utils/db"
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import List from "@/app/models/List"
import Task from "@/app/models/Task"

export async function GET() {
	await connectToDB()
	const session = await getServerSession( authOptions )

	if ( !session || !session.user || !session.user.email ) {
		return NextResponse.json({ error: "Error: Not authenticated." }, { status: 401 })
	}

	const lists = await List.find({ userId: session.user.id }).populate( "tasks" ).lean()

	// Fetch tasks for each list
	const listsWithTasks = await Promise.all(
		lists.map( async ( list ) => {
			const tasks = await Task.find({ listId: list._id }).lean()
			return { ...list, tasks }
		})
	)

	return NextResponse.json( listsWithTasks )
}

export async function POST( req: Request ) {
	await connectToDB()
	const session = await getServerSession( authOptions )

	if ( !session || !session.user || !session.user.email ) {
		return NextResponse.json({ error: "Error: Not authenticated." }, { status: 401 })
	}

	const body = await req.json()
	const newList = await List.create({ ...body, userId: session.user.id })
	return NextResponse.json( newList )
}